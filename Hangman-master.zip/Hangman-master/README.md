# Hangman Game using Javascript, HTML 5 and Bootstap CSS.
